import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Layouts extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Primera app en flutter"),
    ),
      body: Center(

        child: Column(
          mainAxisAlignment: MainAxisAlignment.center ,
          children: <Widget>[
              Row(

              //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  Expanded(
                    child: Column(
                        children: <Widget>[
                          Icon(
                        Icons.favorite,
                        color: Colors.pink,
                        size: 24.0,
                      ),
                      Text("LLamar"),
                ],
              ),
                  ),
                  Expanded(
                    child: Column(
                        children: <Widget>[
                      Icon(
                      Icons.favorite,
                      color: Colors.pink,
                      size: 24.0,
                    ),
                      Text("LLamar"),
                    ],
                    ),
                  ),
                  Expanded(
                   child: Column(
                    children: <Widget>[
                    Icon(
                      Icons.favorite,
                      color: Colors.pink,
                      size: 24.0,
                    ),
                    Text("LLamar"),
                  ],
                    ),
                  ),
            ],
                  ),
          ],
        ),
      ),
    );


  }




}
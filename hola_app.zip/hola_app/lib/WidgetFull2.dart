import 'package:flutter/material.dart';

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {

  Color colorfondo;

  void _asignaColor(colorNombre) {
    setState(() {

      switch(colorNombre){
        case 1:
          colorfondo = Colors.pink;
          break;
        case 2:
          colorfondo = Colors.red;
          break;
        case 3:
          colorfondo = Colors.yellow;
          break;
        default:
          colorfondo = Colors.blue;
      }
    });
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(

        title: Text(widget.title),
        backgroundColor: colorfondo,

      ),
      body: Center(

        child: Column(

          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Container(
                margin: const EdgeInsets.all(20.0),
                child: Text(
                  'Selecciona el color del AppBar:',
                )
            ),
            Expanded(
              child: FittedBox(

              ),

            ),
            OpcionesColor(
              onChanged: _asignaColor,

            ),
          ],
        ),
      ),

    );
  }
}

class OpcionesColor extends StatelessWidget{

  OpcionesColor({Key key, @required this.onChanged}) : super(key: key);

  final ValueChanged<int> onChanged;

  void _handleTap(color) {
    onChanged(color);
  }
  @override
  Widget build(BuildContext context) {

    return Row(

      //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: <Widget>[
        Expanded(
          child: Column(
            children: <Widget>[
              FlatButton(
                color: Colors.pink,
                textColor: Colors.white,
                disabledColor: Colors.grey,
                disabledTextColor: Colors.black,
                padding: EdgeInsets.all(8.0),
                splashColor: Colors.blueAccent,
                onPressed: () {
                  _handleTap(1);
                },
                child: Text(
                  "Pink",
                  style: TextStyle(fontSize: 20.0),
                ),
              )
            ],
          ),
        ),
        Expanded(
          child: Column(
            children: <Widget>[
              FlatButton(
                color: Colors.red,
                textColor: Colors.white,
                disabledColor: Colors.grey,
                disabledTextColor: Colors.black,
                padding: EdgeInsets.all(8.0),
                splashColor: Colors.blueAccent,
                onPressed: () {
                  _handleTap(2);
                },
                child: Text(
                  "Red",
                  style: TextStyle(fontSize: 20.0),
                ),
              )
            ],
          ),
        ),
        Expanded(
          child: Column(
            children: <Widget>[
              FlatButton(
                color: Colors.yellow,
                textColor: Colors.white,
                disabledColor: Colors.grey,
                disabledTextColor: Colors.black,
                padding: EdgeInsets.all(8.0),
                splashColor: Colors.blueAccent,
                onPressed: () {
                  _handleTap(3);
                },
                child: Text(
                  "Yellow",
                  style: TextStyle(fontSize: 20.0),
                ),
              )
            ],
          ),
        ),
      ],
    );

  }


}


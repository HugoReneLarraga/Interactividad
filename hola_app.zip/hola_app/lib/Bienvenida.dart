import 'package:flutter/material.dart';

class Bienvenida extends StatelessWidget{

  @override
  Widget build(BuildContext context) {

    return (Scaffold(
      appBar: AppBar(
        title: Text("Primera app en flutter"),
      ),
      body: Center(
        child: Image.asset('imagenes/logoTecValles.png',
          fit: BoxFit.cover,
        )

      ),
    )
    );
  }
}


import 'package:flutter/material.dart';
import 'package:hola_app/Bienvenida.dart';
import 'package:hola_app/widgetFull.dart';



void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Hola Mundo',
      theme: ThemeData(

        primarySwatch: Colors.blue,
        //brightness: Brightness.dark,
        //primaryColor: Colors.blueGrey
      ),
      debugShowCheckedModeBanner: false,
      home: MyHomePage(title:'Widget con Estado',)
      //MyHomePage(title:"Flutter App")
    );
  }
}

